Thank you for downloading HTML2Text

This product has no copyright at all, you may freely modify any of
the code and use whatever you want in your own projects.

If you have any problems with this software please post on the forum on

www.sourceforge.com

Thanks
	SorceCode



	Credits

Main Code - SourceCode
Debugging - ManilaMike
